// Header file so all the other files can all the main function in main.cpp

#ifndef COMPUTER_SCIENCE_2_LABS_MAIN_H
#define COMPUTER_SCIENCE_2_LABS_MAIN_H
int main();

#endif //COMPUTER_SCIENCE_2_LABS_MAIN_H