file(REMOVE_RECURSE
  "CMakeFiles/Lab_9.dir/LegoSets.cpp.obj"
  "CMakeFiles/Lab_9.dir/LegoSets.cpp.obj.d"
  "CMakeFiles/Lab_9.dir/main.cpp.obj"
  "CMakeFiles/Lab_9.dir/main.cpp.obj.d"
  "Lab_9.exe"
  "Lab_9.exe.manifest"
  "Lab_9.pdb"
  "libLab_9.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Lab_9.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
