
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "C:/Users/jjdom/Desktop/Computer Science 2 Labs/Labs/Lab 9/LegoSets.cpp" "CMakeFiles/Lab_9.dir/LegoSets.cpp.obj" "gcc" "CMakeFiles/Lab_9.dir/LegoSets.cpp.obj.d"
  "C:/Users/jjdom/Desktop/Computer Science 2 Labs/Labs/Lab 9/main.cpp" "CMakeFiles/Lab_9.dir/main.cpp.obj" "gcc" "CMakeFiles/Lab_9.dir/main.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
